import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Supplier, VatType, vatTypeLabels } from "@/data/suppliers";
import { useSavedData } from "@/hooks/useSavedData";
import { supabase } from "@/integrations/supabase/client";
import { FileText, Building2, Plus, Trash2, User, MessageSquare, Save, X, Car, Upload, Paperclip } from "lucide-react";
import { toast } from "sonner";

export type InvoiceType = "commission" | "car_sale" | "rental" | "repair" | "other";

export const invoiceTypeLabels: Record<InvoiceType, string> = {
  commission: "Komisiniai",
  car_sale: "Automobilio pardavimas",
  rental: "Nuoma",
  repair: "Remontas",
  other: "Kita",
};

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  price: number;
  vatType: VatType;
}

export interface CarDetails {
  vin: string;
  plate: string;
  mileage: string;
  notes: string;
}

export interface InvoiceData {
  invoiceNumber: string;
  date: string;
  buyer: Supplier;
  items: InvoiceItem[];
  note: string;
  invoiceType: InvoiceType;
  carDetails?: CarDetails;
  attachments?: string[];
}

interface InvoiceFormProps {
  onGenerate: (data: InvoiceData) => void;
  nextInvoiceNumber?: number;
}

const vatTypeShortLabels: Record<VatType, string> = {
  with_vat: "Su PVM",
  no_vat: "Be PVM",
  vat_exempt: "Neapmokestinama (komisiniai)",
};

const InvoiceForm = ({ onGenerate, nextInvoiceNumber }: InvoiceFormProps) => {
  const { buyers, products, notes, addBuyer, addProduct, addNote, deleteNote, deleteProduct, deleteBuyer } = useSavedData();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [selectedBuyerId, setSelectedBuyerId] = useState<string>("");
  const [customBuyer, setCustomBuyer] = useState<Supplier>({
    id: "custom",
    name: "",
    companyCode: "",
    vatCode: "",
    address: "",
    isCompany: true,
  });
  const [isCustom, setIsCustom] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [items, setItems] = useState<InvoiceItem[]>([
    { id: "1", description: "", quantity: 1, price: 0, vatType: "vat_exempt" },
  ]);
  const [note, setNote] = useState("Apmokėti per 10 d.d nuo sąskaitos gavimo.");
  const [invoiceType, setInvoiceType] = useState<InvoiceType>("commission");
  const [carDetails, setCarDetails] = useState<CarDetails>({
    vin: "",
    plate: "",
    mileage: "",
    notes: "",
  });
  const [attachments, setAttachments] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (nextInvoiceNumber && !invoiceNumber) {
      setInvoiceNumber(nextInvoiceNumber.toString());
    }
  }, [nextInvoiceNumber]);

  // When invoice type changes, adjust default VAT type
  useEffect(() => {
    if (invoiceType === "car_sale") {
      // For car sales, set margin scheme VAT
      setItems(items.map(item => ({ ...item, vatType: "vat_exempt" })));
    }
  }, [invoiceType]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${invoiceNumber || Date.now()}_${Date.now()}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('invoice-attachments')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('invoice-attachments')
          .getPublicUrl(filePath);

        setAttachments(prev => [...prev, publicUrl]);
      }
      toast.success("Failai įkelti!");
    } catch (error) {
      console.error("Error uploading file:", error);
      toast.error("Klaida įkeliant failą");
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const removeAttachment = (url: string) => {
    setAttachments(prev => prev.filter(a => a !== url));
  };

  const handleBuyerChange = (value: string) => {
    if (value === "custom") {
      setIsCustom(true);
      setSelectedBuyerId("");
    } else {
      setIsCustom(false);
      setSelectedBuyerId(value);
    }
  };

  const handleSaveCustomBuyer = async () => {
    if (!customBuyer.name || !customBuyer.companyCode || !customBuyer.address) {
      return;
    }
    await addBuyer({
      name: customBuyer.name,
      company_code: customBuyer.companyCode,
      vat_code: customBuyer.vatCode || null,
      address: customBuyer.address,
      is_company: customBuyer.isCompany,
    });
  };

  const selectProduct = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (product && items.length > 0) {
      const lastItem = items[items.length - 1];
      if (!lastItem.description) {
        updateItem(lastItem.id, "description", product.description);
      } else {
        setItems([
          ...items,
          {
            id: Date.now().toString(),
            description: product.description,
            quantity: 1,
            price: 0,
            vatType: "vat_exempt",
          },
        ]);
      }
    }
  };

  const addItem = () => {
    setItems([
      ...items,
      {
        id: Date.now().toString(),
        description: "",
        quantity: 1,
        price: 0,
        vatType: "vat_exempt",
      },
    ]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter((item) => item.id !== id));
    }
  };

  const updateItem = (
    id: string,
    field: keyof InvoiceItem,
    value: string | number | VatType
  ) => {
    setItems(
      items.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleSaveCurrentNote = async () => {
    if (note.trim() && !notes.find(n => n.text === note)) {
      await addNote(note);
    }
  };

  const handleSaveCurrentProduct = async (item: InvoiceItem) => {
    if (item.description.trim() && !products.find(p => p.description === item.description)) {
      await addProduct(item.description, 0);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let buyer: Supplier;
    if (isCustom) {
      buyer = customBuyer;
    } else {
      const savedBuyer = buyers.find((b) => b.id === selectedBuyerId);
      if (!savedBuyer) return;
      buyer = {
        id: savedBuyer.id,
        name: savedBuyer.name,
        companyCode: savedBuyer.company_code,
        vatCode: savedBuyer.vat_code || "",
        address: savedBuyer.address,
        isCompany: savedBuyer.is_company,
      };
    }

    if (!buyer.name || !invoiceNumber) return;

    onGenerate({
      invoiceNumber,
      date,
      buyer,
      items,
      note,
      invoiceType,
      carDetails: invoiceType === "car_sale" ? carDetails : undefined,
      attachments: attachments.length > 0 ? attachments : undefined,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
      {/* Invoice Details */}
      <div className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            Sąskaitos duomenys
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="invoiceNumber">Sąskaitos numeris</Label>
            <Input
              id="invoiceNumber"
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              placeholder="pvz. 1207"
              className="input-elegant"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="date">Data</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input-elegant"
              required
            />
          </div>
          <div className="space-y-2">
            <Label>Sąskaitos tipas</Label>
            <Select value={invoiceType} onValueChange={(v) => setInvoiceType(v as InvoiceType)}>
              <SelectTrigger className="input-elegant">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50">
                {(Object.keys(invoiceTypeLabels) as InvoiceType[]).map((type) => (
                  <SelectItem key={type} value={type}>
                    {invoiceTypeLabels[type]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Car Details - only shown for car_sale */}
      {invoiceType === "car_sale" && (
        <div className="form-section animate-fade-in">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-primary" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">
              Automobilio duomenys
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>VIN kodas</Label>
              <Input
                value={carDetails.vin}
                onChange={(e) => setCarDetails({ ...carDetails, vin: e.target.value.toUpperCase() })}
                placeholder="WDD2130131A359727"
                className="input-elegant font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label>Valstybinis numeris (SDK)</Label>
              <Input
                value={carDetails.plate}
                onChange={(e) => setCarDetails({ ...carDetails, plate: e.target.value.toUpperCase() })}
                placeholder="ABC123"
                className="input-elegant"
              />
            </div>
            <div className="space-y-2">
              <Label>Rida (km)</Label>
              <Input
                type="number"
                value={carDetails.mileage}
                onChange={(e) => setCarDetails({ ...carDetails, mileage: e.target.value })}
                placeholder="150000"
                className="input-elegant"
              />
            </div>
          </div>
          <div className="mt-4 space-y-2">
            <Label>Papildoma informacija apie automobilį</Label>
            <Textarea
              value={carDetails.notes}
              onChange={(e) => setCarDetails({ ...carDetails, notes: e.target.value })}
              placeholder="pvz. Automobilis be katalizatoriaus, naudotos dalys ir t.t."
              className="input-elegant"
              rows={2}
            />
          </div>
        </div>
      )}

      {/* Buyer Selection */}
      <div className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">Pirkėjas</h2>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Pasirinkite pirkėją</Label>
            <Select onValueChange={handleBuyerChange} value={isCustom ? "custom" : selectedBuyerId}>
              <SelectTrigger className="input-elegant">
                <SelectValue placeholder="Pasirinkite iš sąrašo arba įveskite patys" />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50 max-h-64">
                {buyers.map((buyer) => (
                  <SelectItem key={buyer.id} value={buyer.id}>
                    {buyer.name}
                  </SelectItem>
                ))}
                <SelectItem value="custom">
                  ✏️ Įvesti naują pirkėją
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isCustom && (
            <div className="space-y-4 animate-fade-in">
              {/* Buyer Type */}
              <div className="space-y-2">
                <Label>Pirkėjo tipas</Label>
                <RadioGroup
                  value={customBuyer.isCompany ? "company" : "individual"}
                  onValueChange={(v) =>
                    setCustomBuyer({ ...customBuyer, isCompany: v === "company" })
                  }
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="company" id="company" />
                    <Label htmlFor="company" className="cursor-pointer font-normal flex items-center gap-1">
                      <Building2 className="w-4 h-4" /> Juridinis asmuo
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="individual" id="individual" />
                    <Label htmlFor="individual" className="cursor-pointer font-normal flex items-center gap-1">
                      <User className="w-4 h-4" /> Fizinis asmuo
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{customBuyer.isCompany ? "Pavadinimas" : "Vardas, Pavardė"}</Label>
                  <Input
                    value={customBuyer.name}
                    onChange={(e) =>
                      setCustomBuyer({ ...customBuyer, name: e.target.value })
                    }
                    placeholder={customBuyer.isCompany ? "UAB Įmonė" : "Vardenis Pavardenis"}
                    className="input-elegant"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{customBuyer.isCompany ? "Įmonės kodas" : "Asmens kodas (neprivaloma)"}</Label>
                  <Input
                    value={customBuyer.companyCode}
                    onChange={(e) =>
                      setCustomBuyer({
                        ...customBuyer,
                        companyCode: e.target.value,
                      })
                    }
                    placeholder={customBuyer.isCompany ? "123456789" : ""}
                    className="input-elegant"
                    required={customBuyer.isCompany}
                  />
                </div>
                {customBuyer.isCompany && (
                  <div className="space-y-2">
                    <Label>PVM kodas (neprivaloma)</Label>
                    <Input
                      value={customBuyer.vatCode}
                      onChange={(e) =>
                        setCustomBuyer({ ...customBuyer, vatCode: e.target.value })
                      }
                      placeholder="LT123456789"
                      className="input-elegant"
                    />
                  </div>
                )}
                <div className="space-y-2">
                  <Label>Adresas</Label>
                  <Input
                    value={customBuyer.address}
                    onChange={(e) =>
                      setCustomBuyer({ ...customBuyer, address: e.target.value })
                    }
                    placeholder="Gatvė 1, Miestas"
                    className="input-elegant"
                    required
                  />
                </div>
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleSaveCustomBuyer}
                disabled={!customBuyer.name || !customBuyer.companyCode || !customBuyer.address}
                className="gap-2"
              >
                <Save className="w-4 h-4" />
                Išsaugoti pirkėją į sąrašą
              </Button>
            </div>
          )}

          {selectedBuyerId && !isCustom && (
            <div className="p-4 bg-muted rounded-lg animate-fade-in">
              {(() => {
                const buyer = buyers.find((b) => b.id === selectedBuyerId);
                return buyer ? (
                  <div className="flex justify-between items-start">
                    <div className="text-sm space-y-1 text-muted-foreground">
                      <p className="font-medium text-foreground">{buyer.name}</p>
                      <p>Įmonės kodas: {buyer.company_code}</p>
                      {buyer.vat_code && <p>PVM kodas: {buyer.vat_code}</p>}
                      <p>Adresas: {buyer.address}</p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteBuyer(buyer.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ) : null;
              })()}
            </div>
          )}
        </div>
      </div>

      {/* Items */}
      <div className="form-section">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">
              Prekės / Paslaugos
            </h2>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addItem}
            className="gap-2"
          >
            <Plus className="w-4 h-4" />
            Pridėti
          </Button>
        </div>

        {/* Quick product selection */}
        {products.length > 0 && (
          <div className="mb-4">
            <Label className="text-xs text-muted-foreground mb-2 block">Greitas pasirinkimas:</Label>
            <div className="flex flex-wrap gap-2">
              {products.map((product) => (
                <div key={product.id} className="flex items-center gap-1">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => selectProduct(product.id)}
                    className="text-xs"
                  >
                    {product.description}
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-muted-foreground hover:text-destructive"
                    onClick={() => deleteProduct(product.id)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="p-4 bg-muted/30 rounded-lg space-y-3 animate-fade-in"
            >
              <div className="grid grid-cols-12 gap-3 items-end">
                <div className="col-span-12 md:col-span-5 space-y-2">
                  <Label>Pavadinimas</Label>
                  <Input
                    value={item.description}
                    onChange={(e) =>
                      updateItem(item.id, "description", e.target.value)
                    }
                    placeholder="Paslaugos aprašymas"
                    className="input-elegant"
                    required
                  />
                </div>
                <div className="col-span-4 md:col-span-2 space-y-2">
                  <Label>Kiekis</Label>
                  <Input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) =>
                      updateItem(item.id, "quantity", parseInt(e.target.value) || 1)
                    }
                    className="input-elegant"
                    required
                  />
                </div>
                <div className="col-span-5 md:col-span-2 space-y-2">
                  <Label>Kaina (€)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={item.price === 0 ? "" : item.price}
                    onChange={(e) =>
                      updateItem(item.id, "price", e.target.value === "" ? 0 : parseFloat(e.target.value))
                    }
                    className="input-elegant"
                    required
                  />
                </div>
                <div className="col-span-3 md:col-span-2 flex gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => handleSaveCurrentProduct(item)}
                    disabled={!item.description.trim()}
                    className="text-primary hover:text-primary hover:bg-primary/10"
                    title="Išsaugoti į sąrašą"
                  >
                    <Save className="w-4 h-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeItem(item.id)}
                    disabled={items.length === 1}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {/* Per-item VAT type */}
              <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                <Label className="text-xs text-muted-foreground whitespace-nowrap">PVM:</Label>
                <div className="flex flex-wrap gap-2">
                  {(Object.keys(vatTypeShortLabels) as VatType[]).map((type) => (
                    <Button
                      key={type}
                      type="button"
                      variant={item.vatType === type ? "default" : "outline"}
                      size="sm"
                      onClick={() => updateItem(item.id, "vatType", type)}
                      className="text-xs h-7 px-2"
                    >
                      {vatTypeShortLabels[type]}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Note */}
      <div className="form-section">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">Pastaba</h2>
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {notes.map((n) => (
              <div key={n.id} className="flex items-center gap-1">
                <Button
                  type="button"
                  variant={note === n.text ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNote(n.text)}
                  className="text-xs"
                >
                  {n.text.length > 25 ? n.text.substring(0, 25) + "..." : n.text}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-muted-foreground hover:text-destructive"
                  onClick={() => deleteNote(n.id)}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ))}
            <Button
              type="button"
              variant={note === "" ? "default" : "outline"}
              size="sm"
              onClick={() => setNote("")}
              className="text-xs"
            >
              Be pastabos
            </Button>
          </div>
          <div className="flex gap-2">
            <Textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="input-elegant flex-1"
              rows={2}
              placeholder="Arba įveskite savo pastabą..."
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={handleSaveCurrentNote}
              disabled={!note.trim() || notes.some(n => n.text === note)}
              className="self-end"
              title="Išsaugoti pastabą"
            >
              <Save className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Attachments */}
      <div className="form-section">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Paperclip className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">Priedai</h2>
        </div>

        <div className="space-y-3">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            multiple
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            className="hidden"
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="gap-2"
          >
            <Upload className="w-4 h-4" />
            {uploading ? "Įkeliama..." : "Įkelti failus"}
          </Button>

          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {attachments.map((url, index) => (
                <div key={index} className="flex items-center gap-2 bg-muted px-3 py-1 rounded-lg text-sm">
                  <Paperclip className="w-3 h-3" />
                  <span className="max-w-[150px] truncate">
                    {url.split('/').pop()}
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 text-muted-foreground hover:text-destructive"
                    onClick={() => removeAttachment(url)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <Button type="submit" className="w-full btn-gradient h-12 text-lg">
        <FileText className="w-5 h-5 mr-2" />
        Generuoti sąskaitą faktūrą
      </Button>
    </form>
  );
};

export default InvoiceForm;
