import { SavedInvoice } from "@/hooks/useInvoices";
import { Button } from "@/components/ui/button";
import { Eye, Trash2, FileText, Calendar, Building2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface InvoiceHistoryProps {
  invoices: SavedInvoice[];
  loading: boolean;
  onView: (invoice: SavedInvoice) => void;
  onDelete: (id: string) => void;
}

const InvoiceHistory = ({
  invoices,
  loading,
  onView,
  onDelete,
}: InvoiceHistoryProps) => {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("lt-LT");
  };

  const formatCurrency = (amount: number) => {
    return `${amount.toFixed(2)}€`;
  };

  if (loading) {
    return (
      <div className="form-section animate-fade-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            Išrašytos sąskaitos
          </h2>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          Kraunama...
        </div>
      </div>
    );
  }

  if (invoices.length === 0) {
    return (
      <div className="form-section animate-fade-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            Išrašytos sąskaitos
          </h2>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          Dar nėra išsaugotų sąskaitų
        </div>
      </div>
    );
  }

  return (
    <div className="form-section animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">
          Išrašytos sąskaitos ({invoices.length})
        </h2>
      </div>

      <div className="space-y-3">
        {invoices.map((invoice) => (
          <div
            key={invoice.id}
            className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
          >
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <div className="flex-shrink-0 w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-lg font-bold text-primary">
                  #{invoice.invoice_number}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span className="font-medium text-foreground truncate">
                    {invoice.buyer_name}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formatDate(invoice.invoice_date)}
                  </span>
                  <span className="font-semibold text-primary">
                    {formatCurrency(invoice.total_amount)}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onView(invoice)}
                className="gap-1"
              >
                <Eye className="w-4 h-4" />
                Peržiūrėti
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-card">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Ištrinti sąskaitą?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ar tikrai norite ištrinti sąskaitą Nr.{" "}
                      {invoice.invoice_number}? Šis veiksmas negrįžtamas.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Atšaukti</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => onDelete(invoice.id)}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Ištrinti
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InvoiceHistory;
