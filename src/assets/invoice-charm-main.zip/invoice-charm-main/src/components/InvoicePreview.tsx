import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { InvoiceData, InvoiceItem, InvoiceType } from "./InvoiceForm";
import { sellerInfo, VatType } from "@/data/suppliers";
import { Download, Printer, ArrowLeft, Paperclip } from "lucide-react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import logo from "@/assets/logo.png";

interface InvoicePreviewProps {
  data: InvoiceData;
  onBack: () => void;
}

const InvoicePreview = ({ data, onBack }: InvoicePreviewProps) => {
  const invoiceRef = useRef<HTMLDivElement>(null);

  // Group items by VAT type and calculate totals
  const calculateTotals = () => {
    let totalWithVat = 0;
    let totalNoVat = 0;
    let totalVatExempt = 0;

    data.items.forEach((item) => {
      const itemTotal = item.quantity * item.price;
      if (item.vatType === "with_vat") {
        totalWithVat += itemTotal;
      } else if (item.vatType === "no_vat") {
        totalNoVat += itemTotal;
      } else {
        totalVatExempt += itemTotal;
      }
    });

    // For with_vat items, price includes VAT, calculate backwards
    const withVatBase = totalWithVat / 1.21;
    const vatAmount = totalWithVat - withVatBase;

    const grandTotal = totalWithVat + totalNoVat + totalVatExempt;
    const totalBase = withVatBase + totalNoVat + totalVatExempt;

    return {
      totalWithVat,
      totalNoVat,
      totalVatExempt,
      withVatBase,
      vatAmount,
      grandTotal,
      totalBase,
      hasVatItems: totalWithVat > 0,
      hasVatExemptItems: totalVatExempt > 0,
    };
  };

  const totals = calculateTotals();

  const formatDate = (dateStr: string) => {
    return dateStr;
  };

  const formatCurrency = (amount: number) => {
    return `${amount.toFixed(2)}€`;
  };

  const getVatLabel = (vatType: VatType) => {
    if (vatType === "with_vat") return "21%";
    if (vatType === "vat_exempt") return "Neapm.";
    return "-";
  };

  const isCarSale = data.invoiceType === "car_sale";

  const downloadPDF = async () => {
    if (!invoiceRef.current) return;

    const canvas = await html2canvas(invoiceRef.current, {
      scale: 2,
      backgroundColor: "#ffffff",
      useCORS: true,
    });

    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const imgWidth = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
    pdf.save(`Saskaita_${data.invoiceNumber}.pdf`);
  };

  const printInvoice = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3 justify-center print:hidden">
        <Button onClick={onBack} variant="outline" className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Grįžti
        </Button>
        <Button onClick={downloadPDF} className="btn-gradient gap-2">
          <Download className="w-4 h-4" />
          Atsisiųsti PDF
        </Button>
        <Button onClick={printInvoice} className="btn-accent gap-2">
          <Printer className="w-4 h-4" />
          Spausdinti
        </Button>
      </div>

      {/* Attachments list */}
      {data.attachments && data.attachments.length > 0 && (
        <div className="max-w-3xl mx-auto print:hidden">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Paperclip className="w-4 h-4" />
            <span>Priedai:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {data.attachments.map((url, index) => (
              <a
                key={index}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-primary hover:underline bg-muted px-3 py-1 rounded"
              >
                {url.split('/').pop()}
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Invoice */}
      <div
        ref={invoiceRef}
        id="invoice-print"
        className="bg-white max-w-3xl mx-auto shadow-lg print:shadow-none print:max-w-none p-10"
        style={{ fontFamily: "Arial, sans-serif", color: "#333" }}
      >
        {/* Header */}
        <div className="flex justify-between items-start mb-8 pb-6 border-b border-gray-300">
          <img src={logo} alt="Auto Kopers" className="h-10" />
          <div className="text-right">
            <h1 className="text-xl font-bold text-gray-800 mb-1">
              PVM SĄSKAITA FAKTŪRA
            </h1>
            <p className="text-lg font-semibold text-gray-700">
              Nr. {data.invoiceNumber}
            </p>
            <p className="text-gray-600">{formatDate(data.date)}</p>
          </div>
        </div>

        {/* Parties */}
        <div className="grid grid-cols-2 gap-10 mb-8">
          {/* Seller */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
              Pardavėjas
            </h3>
            <div className="text-sm text-gray-700 space-y-0.5">
              <p className="font-semibold text-gray-900">{sellerInfo.name}</p>
              <p>Įmonės kodas: {sellerInfo.companyCode}</p>
              <p>PVM mokėtojo kodas: {sellerInfo.vatCode}</p>
              <p>{sellerInfo.address}</p>
              <p className="mt-2">Sąsk.nr: {sellerInfo.bankAccount}</p>
              <p>{sellerInfo.bankName}</p>
            </div>
          </div>

          {/* Buyer */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
              Pirkėjas
            </h3>
            <div className="text-sm text-gray-700 space-y-0.5">
              <p className="font-semibold text-gray-900">{data.buyer.name}</p>
              {data.buyer.companyCode && (
                <p>{data.buyer.isCompany ? "Įmonės kodas" : "A.K"}: {data.buyer.companyCode}</p>
              )}
              {data.buyer.vatCode && (
                <p>PVM mokėtojo kodas: {data.buyer.vatCode}</p>
              )}
              <p>Adresas: {data.buyer.address}</p>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <table className="w-full text-sm mb-6">
          <thead>
            <tr className="border-y border-gray-300 bg-gray-50">
              <th className="text-left py-2 px-2 font-semibold text-gray-700 w-10">
                Eil.
              </th>
              <th className="text-left py-2 px-2 font-semibold text-gray-700">
                Prekės / paslaugos aprašymas
              </th>
              <th className="text-center py-2 px-2 font-semibold text-gray-700 w-16">
                Kiekis
              </th>
              <th className="text-right py-2 px-2 font-semibold text-gray-700 w-20">
                Kaina
              </th>
              <th className="text-center py-2 px-2 font-semibold text-gray-700 w-16">
                PVM
              </th>
              <th className="text-right py-2 px-2 font-semibold text-gray-700 w-24">
                Suma
              </th>
            </tr>
          </thead>
          <tbody>
            {data.items.map((item, index) => {
              // For car sales, include VIN and plate in description
              let description = item.description;
              if (isCarSale && data.carDetails && index === 0) {
                const parts = [item.description];
                if (data.carDetails.vin) parts.push(data.carDetails.vin);
                if (data.carDetails.plate) parts.push(`SDK: ${data.carDetails.plate}`);
                description = parts.join(' ');
              }

              return (
                <tr key={item.id} className="border-b border-gray-200">
                  <td className="py-2 px-2 text-gray-600">{index + 1}</td>
                  <td className="py-2 px-2 text-gray-800">{description}</td>
                  <td className="py-2 px-2 text-center text-gray-600">
                    {item.quantity}
                  </td>
                  <td className="py-2 px-2 text-right text-gray-600">
                    {formatCurrency(item.price)}
                  </td>
                  <td className="py-2 px-2 text-center text-gray-500 text-xs">
                    {getVatLabel(item.vatType)}
                  </td>
                  <td className="py-2 px-2 text-right text-gray-800">
                    {formatCurrency(item.quantity * item.price)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Car mileage and notes */}
        {isCarSale && data.carDetails && (
          <div className="text-sm text-gray-700 mb-4 space-y-1">
            {data.carDetails.mileage && (
              <p>Rida: {data.carDetails.mileage} km</p>
            )}
            {data.carDetails.notes && (
              <p>{data.carDetails.notes}</p>
            )}
          </div>
        )}

        {/* Totals */}
        <div className="flex justify-end mb-6">
          <div className="w-72 text-sm">
            {totals.hasVatItems && (
              <>
                <div className="flex justify-between py-1 text-gray-600">
                  <span>Suma be PVM:</span>
                  <span>{formatCurrency(totals.totalBase)}</span>
                </div>
                <div className="flex justify-between py-1 text-gray-600">
                  <span>PVM 21%:</span>
                  <span>{formatCurrency(totals.vatAmount)}</span>
                </div>
              </>
            )}
            {!totals.hasVatItems && totals.hasVatExemptItems && (
              <div className="flex justify-between py-1 text-gray-600">
                <span>PVM 21%:</span>
                <span>0€</span>
              </div>
            )}
            <div className="flex justify-between py-2 border-t border-gray-400 mt-1 font-bold text-gray-900">
              <span>{totals.hasVatItems ? "Iš viso (SU PVM):" : "Iš viso:"}</span>
              <span>{formatCurrency(totals.grandTotal)}</span>
            </div>
          </div>
        </div>

        {/* VAT Notice - different for car sales vs commission */}
        {isCarSale ? (
          <p className="text-xs text-gray-600 mb-4">
            Papildoma informacija: Taikomas LR PVM įstatymo 106 str. Apmokestinama taikant maržos schemą / Margin scheme.
          </p>
        ) : totals.hasVatExemptItems ? (
          <p className="text-xs text-gray-500 italic mb-4">
            PVM įstatymu 28 straipsnio 1 dalimi, komisinis mokestis
            (tarpininkavimo paslaugos dėl paskolos suteikimo) nėra PVM objektas
          </p>
        ) : null}

        {/* Note */}
        {data.note && (
          <p className="text-sm text-gray-700 mb-6">
            {data.note}
          </p>
        )}

        {/* Footer with signatures */}
        <div className="pt-4 border-t border-gray-300 mt-8">
          <div className="grid grid-cols-2 gap-10">
            <div>
              <p className="text-sm text-gray-600 mb-8">Sąskaitą išrašė:</p>
              <div className="border-b border-gray-400 mb-1"></div>
              <p className="text-sm text-gray-700">Jurgita Sabeckytė</p>
              <p className="text-xs text-gray-500">{sellerInfo.name}</p>
              <p className="text-xs text-gray-500">Vadovė</p>
            </div>
            {isCarSale && (
              <div>
                <p className="text-sm text-gray-600 mb-8">Pirkėjas:</p>
                <div className="border-b border-gray-400 mb-1"></div>
                <p className="text-sm text-gray-700">{data.buyer.name}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          @page {
            margin: 15mm;
            size: A4;
          }
          body {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          #invoice-print {
            box-shadow: none !important;
            padding: 0 !important;
          }
        }
      `}</style>
    </div>
  );
};

export default InvoicePreview;
