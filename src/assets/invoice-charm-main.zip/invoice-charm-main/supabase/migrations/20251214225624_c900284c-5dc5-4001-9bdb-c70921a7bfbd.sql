-- Create table for storing invoices
CREATE TABLE public.invoices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
  buyer_name TEXT NOT NULL,
  buyer_company_code TEXT NOT NULL,
  buyer_vat_code TEXT,
  buyer_address TEXT NOT NULL,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  note TEXT,
  vat_exempt BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- Create policy for public access (internal tool, no auth needed)
CREATE POLICY "Allow all operations on invoices" 
ON public.invoices 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Create index for faster searching by invoice number
CREATE INDEX idx_invoices_number ON public.invoices(invoice_number);

-- Create index for date-based queries
CREATE INDEX idx_invoices_date ON public.invoices(invoice_date DESC);