-- Drop existing public policy
DROP POLICY IF EXISTS "Allow all operations on invoices" ON public.invoices;

-- Create policies for authenticated users only
CREATE POLICY "Authenticated users can view invoices" 
ON public.invoices 
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert invoices" 
ON public.invoices 
FOR INSERT 
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can delete invoices" 
ON public.invoices 
FOR DELETE 
TO authenticated
USING (true);