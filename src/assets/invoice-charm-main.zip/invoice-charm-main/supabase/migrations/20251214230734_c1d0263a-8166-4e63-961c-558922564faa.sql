-- Add new columns for buyer type and VAT type
ALTER TABLE public.invoices 
ADD COLUMN buyer_is_company BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN vat_type TEXT NOT NULL DEFAULT 'vat_exempt';

-- Drop old vat_exempt column
ALTER TABLE public.invoices DROP COLUMN IF EXISTS vat_exempt;