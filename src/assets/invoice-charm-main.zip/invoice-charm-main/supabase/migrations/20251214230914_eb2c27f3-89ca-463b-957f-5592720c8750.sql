-- Update RLS to allow public access (no auth required)
DROP POLICY IF EXISTS "Authenticated users can view invoices" ON public.invoices;
DROP POLICY IF EXISTS "Authenticated users can insert invoices" ON public.invoices;
DROP POLICY IF EXISTS "Authenticated users can delete invoices" ON public.invoices;

CREATE POLICY "Public can view invoices" 
ON public.invoices 
FOR SELECT 
USING (true);

CREATE POLICY "Public can insert invoices" 
ON public.invoices 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Public can delete invoices" 
ON public.invoices 
FOR DELETE 
USING (true);