-- Table for saved custom notes
CREATE TABLE public.saved_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  text TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.saved_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public access saved_notes" ON public.saved_notes FOR ALL USING (true) WITH CHECK (true);

-- Table for saved products/services
CREATE TABLE public.saved_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  description TEXT NOT NULL,
  default_price DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.saved_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public access saved_products" ON public.saved_products FOR ALL USING (true) WITH CHECK (true);

-- Table for saved buyers/clients
CREATE TABLE public.saved_buyers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  company_code TEXT NOT NULL,
  vat_code TEXT,
  address TEXT NOT NULL,
  is_company BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.saved_buyers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public access saved_buyers" ON public.saved_buyers FOR ALL USING (true) WITH CHECK (true);

-- Insert default buyers from user's invoices
INSERT INTO public.saved_buyers (name, company_code, vat_code, address, is_company) VALUES
('Bigbank AS filialas', '301048563', 'LT100004120611', 'Jogailos g. 4, Vilnius', true),
('AS Inbank filialas', '305340173', 'LT100012843518', 'Kareivių g. 11B, Vilnius', true),
('UAB "SILITA"', '132915039', 'LT329150314', 'Laisvės al. 11-2, Kaunas', true),
('SEB lizingas', '111681846', 'LT116818415', 'Gedimino pr. 12, Vilnius', true),
('Swedbank lizingas', '211439080', 'LT114390811', 'Konstitucijos pr. 20A, Vilnius', true),
('UAB Mokilizingas', '302831331', 'LT100007174510', 'J. Basanavičiaus g. 26, Vilnius', true);

-- Insert default notes
INSERT INTO public.saved_notes (text) VALUES
('Apmokėti per 10 d.d nuo sąskaitos gavimo.'),
('Apmokėti per 14 d.d nuo sąskaitos gavimo.'),
('Apmokėti per 30 d.d nuo sąskaitos gavimo.'),
('Apmokėti iš karto.'),
('Apmokėta.');

-- Insert default products
INSERT INTO public.saved_products (description, default_price) VALUES
('Komisinis atlyginimas', 0),
('Tarpininkavimo paslaugos (komisinis atlyginimas)', 0),
('Patalpų subnuoma', 510.00),
('Komunaliniai mokesčiai', 0);