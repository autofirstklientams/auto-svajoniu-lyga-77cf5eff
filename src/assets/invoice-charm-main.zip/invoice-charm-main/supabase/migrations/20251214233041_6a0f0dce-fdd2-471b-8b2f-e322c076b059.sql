-- Create storage bucket for invoice attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('invoice-attachments', 'invoice-attachments', true);

-- Storage policies for invoice attachments
CREATE POLICY "Public can view invoice attachments"
ON storage.objects FOR SELECT
USING (bucket_id = 'invoice-attachments');

CREATE POLICY "Public can upload invoice attachments"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'invoice-attachments');

CREATE POLICY "Public can delete invoice attachments"
ON storage.objects FOR DELETE
USING (bucket_id = 'invoice-attachments');

-- Add invoice_type and car_details columns to invoices table
ALTER TABLE public.invoices 
ADD COLUMN invoice_type text NOT NULL DEFAULT 'commission',
ADD COLUMN car_vin text,
ADD COLUMN car_plate text,
ADD COLUMN car_mileage integer,
ADD COLUMN car_notes text,
ADD COLUMN attachments jsonb DEFAULT '[]'::jsonb;

-- Update RLS to allow updates
CREATE POLICY "Public can update invoices"
ON public.invoices
FOR UPDATE
USING (true)
WITH CHECK (true);